#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/5/13 15:47
# @Author  : xinfa.jiang
# @Site    : 
# @File    : beam search.py
# @Software: PyCharm

import numpy as np


def beam_search(model, src_input, k=3, sequence_max_len=25):
    k_beam = [(0, [0] * (sequence_max_len + 1))]

    for l in range(sequence_max_len):
        all_k_beams = []
        for prob, sent_predict in k_beam:
            predicted = model.predict([np.array([src_input]), np.array([sent_predict])])[0]

            prossible_k = predicted[1].argsort()[-k:][::-1]

            all_k_beams += [(sum(np.log(predicted[i][sent_predict[i + 1]]) for i in range(1)) + np.log(
                predicted[1][next_wid]), list(sent_predict[:l + 1]) + [next_wid] + [0] * sequence_max_len - 1 - 1) for
                            next_wid in prossible_k]

            k_beam = sorted(all_k_beams)[-k:]
    return k_beam
