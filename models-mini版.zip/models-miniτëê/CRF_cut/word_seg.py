import numpy as np
from tensorflow.keras.callbacks import Callback
from tqdm import tqdm

from CRF_cut.Util import Data_util, Model_util, CRF_util

np.random.seed(123)

# 分词后的句子
sents = Data_util.load_sents(file_path='sents_list.pkl')
# 字典
chars = Data_util.load_chars(file_path='chars_dic.pkl', sents=sents)
np.random.shuffle(sents)

id2char = {i + 1: j for i, j in enumerate(chars)}
char2id = {j: i for i, j in id2char.items()}

# n:额外标记
id2tag = {0: 's', 1: 'b', 2: 'm', 3: 'e', 4: 'n'}
tag2id = {j: i for i, j in id2tag.items()}

train_sents = sents[:-5000]
valid_sents = sents[-50:]

batch_size = 4
embedding_size = 128

model = Model_util.define_model(len(chars) + 1, embedding_size)


class Evaluate(Callback):
    def __init__(self):
        self.highest = 0.

    @staticmethod
    def cut(s, trans):
        if not s:
            return []
        # 字序列转化为id序列。注意，经过我们前面对语料的预处理，字符集是没有空格的，
        # 所以这里简单将空格的id跟句号的id等同起来
        sent_ids = np.array([[char2id.get(c, 0) if c != ' ' else char2id[u'。']
                              for c in s]])
        probas = model.predict(sent_ids)[0]  # 模型预测
        nodes = [dict(zip('sbme', i)) for i in probas[:, :4]]  # 只取前4个
        nodes[0] = {i: j for i, j in nodes[0].items() if i in 'bs'}  # 首字标签只能是b或s
        nodes[-1] = {i: j for i, j in nodes[-1].items() if i in 'es'}  # 末字标签只能是e或s
        tags = CRF_util.viterbi(nodes, trans)[0]
        result = [s[0]]
        for i, j in zip(s[1:], tags[1:]):
            if j in 'bs':  # 词的开始
                result.append(i)
            else:  # 接着原来的词
                result[-1] += i
        return result

    def on_epoch_end(self, epoch, logs=None):
        weigth = model.get_weights()
        # 从训练模型中取出最新得到的：转移矩阵
        weigth_end = weigth[-1][:4, :4]
        trans = {}
        for i in 'sbme':
            for j in 'sbme':
                trans[i + j] = weigth_end[tag2id[i], tag2id[j]]
        right = 0.
        total = 0.
        for s in tqdm(iter(valid_sents), desc=u'验证模型中'):
            result = self.cut(''.join(s), trans)
            total += len(set(s))
            right += len(set(s) & set(result))  # 直接将词集的交集作为正确数。该指标比较简单，
            # 也许会导致估计偏高。读者可以考虑自定义指标
        acc = right / total
        if acc > self.highest:
            self.highest = acc
        print('val acc: %s, highest: %s' % (acc, self.highest))


from tensorflow.keras.utils import plot_model

plot_model(model, to_file='model.png', show_shapes=True)

evaluator = Evaluate()
model.fit_generator(Data_util.train_generator(train_sents, char2id, tag2id, batch_size),
                    steps_per_epoch=20,
                    epochs=10,
                    callbacks=[evaluator])  # 训练并将evaluator加入到训练过程
