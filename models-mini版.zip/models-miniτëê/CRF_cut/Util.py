#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/11/19 2:58 PM
# @Author  : xinfa.jiang
# @Site    : 
# @File    : data_util.py
# @Software: PyCharm
import pickle, os, re
import numpy as np
from tensorflow.keras.utils import to_categorical
from CRF_cut.crf_keras import CRF
from tensorflow.keras.layers import Dense, Embedding, Conv1D, Input
from tensorflow.keras.models import Model
import logging

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s %(name)s %(levelname)s %(message)s",
                    datefmt='%Y-%m-%d  %H:%M:%S %a'
                    )


class Data_util:
    def __init__(self):
        pass

    @staticmethod
    def load_sents(file_path='sents_list.pkl'):
        def save_sents(sents, filepath):
            with open(file=filepath, mode='wb+') as f:
                pickle.dump(sents, f)

        if os.path.exists(file_path):
            with open(file=file_path, mode='rb') as f:
                sents = pickle.load(f)
                return sents
        else:
            sents = open('../data/msr_training.utf8', encoding='utf-8').read()
            sents = sents.strip()
            sents = sents.split('\n')  # 这个语料的换行符是\r\n
            sents = [re.split(' +', s) for s in sents]  # 词之间以空格隔开
            sents = [[w for w in s if w] for s in sents]  # 去掉空字符串
            save_sents(sents, file_path)
            return sents

    @staticmethod
    def load_chars(file_path='chars_dict.pkl', sents=None):
        def save_chars(chars, filepath):
            with open(file=filepath, mode='wb+') as f:
                pickle.dump(chars, f)

        if os.path.exists(file_path):
            with open(file=file_path, mode='rb') as f:
                chars = pickle.load(f)
                return chars
        else:
            chars = {}  # 统计字表
            for s in sents:
                for c in ''.join(s):
                    if c in chars:
                        chars[c] += 1
                    else:
                        chars[c] = 1

            min_count = 2  # 过滤低频字
            chars = {i: j for i, j in chars.items() if j >= min_count}
            save_chars(chars, file_path)
            return chars

    @staticmethod
    def train_generator(train_sents, char2id, tag2id, batch_size):
        while True:
            X, Y = [], []
            for i, s in enumerate(train_sents):
                sx, sy = [], []
                for w in s:
                    sx.extend([char2id.get(c, 0) for c in w])
                    if len(w) == 1:
                        sy.append(tag2id.get('s'))
                    else:
                        sy.extend([tag2id.get('b')] + [tag2id.get('m')] * (len(w) - 2) + [tag2id.get('e')])
                # 字的id
                X.append(sx)
                # 标注的id
                Y.append(sy)
                if len(X) == batch_size or i == len(train_sents) - 1:
                    # 同一个batch内长度对齐，换了一个Batch了，可以是另外那个Batch内的maxlen。只要保证一个Batch一样长就行
                    maxlen = max([len(x) for x in X])  # 找出最大字数
                    X = [x + [tag2id.get('s')] * (maxlen - len(x)) for x in X]  # 不足则补零
                    Y = [y + [tag2id.get('n')] * (maxlen - len(y)) for y in Y]  # 不足则补第五个标签
                    YY = to_categorical(Y, len(tag2id.keys()))
                    yield np.array(X), YY
                    X, Y = [], []


class Model_util:
    def __init__(self):
        pass

    @staticmethod
    def define_model(input_dim, embedding_size):
        # batch size x max_batch_seq_len
        sequence = Input(shape=(None,), dtype='int32')
        # batch size x max_batch_seq_len x embedding_size
        embedding = Embedding(input_dim,
                              embedding_size,
                              )(sequence)
        # batch size x max_batch_seq_len x 128
        cnn = Conv1D(128, 3, activation='relu', padding='same')(embedding)
        # batch size x max_batch_seq_len x 128
        cnn = Conv1D(128, 3, activation='relu', padding='same')(cnn)
        # batch size x max_batch_seq_len x 128
        cnn = Conv1D(128, 3, activation='relu', padding='same')(cnn)

        crf = CRF(True)  # 定义crf层，参数为True，自动mask掉最后一个标签
        # batch size x max_batch_seq_len x 5
        tag_score = Dense(5)(cnn)  # 变成了5分类，第五个标签用来mask掉
        # batch size x max_batch_seq_len x 5。代表对每个字的5分类预测
        tag_score = crf(tag_score)

        model = Model(inputs=sequence, outputs=tag_score)
        model.summary()

        model.compile(loss=crf.loss,  # 用crf自带的loss
                      optimizer='adam',
                      metrics=[crf.accuracy]  # 用crf自带的accuracy
                      )
        return model


class CRF_util:
    def __init__(self):
        pass

    @staticmethod
    def max_in_dict(d):  # 定义一个求字典中最大值的函数
        key, value = list(d.items())[0]
        for i, j in list(d.items())[1:]:
            if j > value:
                key, value = i, j
        return key, value

    @staticmethod
    def viterbi(nodes_state, trans_state):
        '''
        @nodes_state 节点上的状态特征，{'e':0.666}之类的
        @trans_state 边上的转移特征，{'bm':0.666}之类的
        每个节点有所有可能状态(embs)，每个边也是所有可能的合理状态(ss,bm,be,me)
        此时的viterbi算法动态规划，寻找最佳打分路径，找到节点序列对应的状态分最高的路径。
        这个路径经过的状态embsembs....就是节点的状态，代表分词、词性标注
        -----------------
        形象化思路：通往成功的道路假如需要10000小时，分作一万个节点，每个小时（节点）你可能处于各种状态（吃喝拉撒学习打牌）称为状态特征nodes_state
        而当前的每个状态在下一个小时又回转成其它可能状态（吃->拉，拉->吃，但是有些状态是不合理的：瑜伽->跳广场舞，安装抖音->卸载抖音），称转移特征trans_state
        假如大自然有成功秘诀，具体不知道，但是大致是：读书状态比拉屎状态对你成功贡献更大（权重更大）
        起床->读书，比起床->蹦迪转移状态对你成功贡献更大（权重更大）
        现在：你并不知道你该如何去获得成功
        所以你把成功人士的各种状态，状态转移关系统计出来了。称作训练样本
        马云：读书、吃饭、陪外国人聊天、吃饭、教书、睡觉、....；马化腾：...
        然后你需要借助一些模型，或者统计学专家，帮你设计/找到以上每个状态、状态转移，对你成功的具体分数多少。（实在不行你也能估，拉屎的分数肯定比读书少...）
        viterbi算法接下来，就能计算出，在1万小时后，得到最大成功概率，所需要每个小时做的事情（人的生路线规划）
        然后你按照那个路径走，你就能很大概率成功了
        -----------------
        viterbi算法细节理解：显然虽然读书比拉屎贡献更大，但是1万小时一直读书，那么你会憋死、饿死，成功概率为0；
        所以viterbi算法并不会每一步都只基于上一步最优，到现在这步最优，去计算路径。
        而是上一步最优到这一步所有状态，保留为一个集合，再下一步的时候考虑上一步的集合中所有可能到当前状态的所有可能
        （到上一时刻最优路径集合的最后一个状态可能是：吃喝拉撒各种，
        当前也可能是吃喝拉撒，当前吃，考虑上一步吃喝拉撒->现在吃；当前喝，考虑上一步吃喝拉撒->现在喝，然后再计算出最优路径集合）
        以此类推，到最后一万小时后，才选最终最大分数的作为输出路径，这个得出的最优人生规划，考虑了你吃喝拉撒所以可能，才给出你最优路径
        '''
        paths = nodes_state[0]
        for l in range(1, len(nodes_state)):
            paths_old, paths = paths, {}
            for n, ns in nodes_state[l].items():  # 当前时刻的所有节点状态遍历
                max_path, max_score = '', -1e10
                for path, path_score in paths_old.items():  # 截止至前一时刻的最优路径集合，p到上一时刻路径，ps路径分数
                    trans_state_before_to_now = path[-1] + n  # 上一状态p[-1]转移到现在状态n
                    trans_score_before_to_now = trans_state[trans_state_before_to_now]
                    score = ns + path_score + trans_score_before_to_now  # 计算新分数
                    if score > max_score:  # 如果新分数大于已有的最大分
                        max_path, max_score = path + n, score  # 更新路径
                # 储存到当前节点(字)，所有可的最优路径，及对应分数。因为只有在最后一刻序列末尾，才能真正得到最高分数路径
                paths[max_path] = max_score
        # 计算最后一个节点完了，此刻所有最优的最大分数，取那个分数的路径
        max_path, max_socre = CRF_util.max_in_dict(paths)
        return max_path
