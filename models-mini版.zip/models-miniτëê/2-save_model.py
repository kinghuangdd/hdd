
import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

'''
model = LinearRegression()
# ......各种操作
model.eval()
#训练完成，保存状态字典到linear.pkl
torch.save(model.state_dict(), './linear.pkl')


model = LinearRegression()
model.load_state_dict(torch.load('linear.pth'))
#...各种使用，比如预测...
x_test=np.arrar([..............])
x_test = torch.from_numpy(x_test)
predict_y = model(Variable(x_test))

'''