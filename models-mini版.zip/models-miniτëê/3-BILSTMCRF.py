import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.optim as optim

torch.manual_seed(1)


def argmax(vec):
    # return the argmax as a python int
    _, idx = torch.max(vec, 1)
    return idx.item()


def prepare_sequence(seq, to_ix):
    # 准备训练数据
    idxs = [to_ix[w] for w in seq]
    return torch.tensor(idxs, dtype=torch.long)


def log_sum_exp(vec):
    # log \sum(e^x1,..,e^xn)
    max_score = vec[0, argmax(vec)]
    max_score_broadcast = max_score.view(1, -1).expand(1, vec.size()[1])
    # 前面几步只是为了把最大的变成1，缩小尺度/归一化
    p = torch.exp(vec - max_score_broadcast)  # e^(x)
    p = torch.sum(p)
    p = torch.log(p)
    return max_score + p


class BiLSTM_CRF(nn.Module):
    # Bi-LSMT-CRF
    def __init__(self, vocab_size, tag_to_ix, embedding_dim, hidden_dim):
        super(BiLSTM_CRF, self).__init__()
        # 词向量设置大小
        self.embedding_dim = embedding_dim
        # 隐藏层大小
        self.hidden_dim = hidden_dim
        # 词汇表大小
        self.vocab_size = vocab_size
        # 标签 to 索引
        self.tag_to_ix = tag_to_ix
        # 标签数量
        self.tagset_size = len(tag_to_ix)
        # 词嵌入
        self.word_embeds = nn.Embedding(vocab_size, embedding_dim)
        # bi-lstm
        self.lstm = nn.LSTM(embedding_dim, hidden_dim // 2,
                            num_layers=1, bidirectional=True)
        # LSTM 输出的状态（标签 tag）概率.
        self.hidden2tag = nn.Linear(hidden_dim, self.tagset_size)
        # 转移状态概率矩阵
        self.transitions = nn.Parameter(torch.randn(self.tagset_size, self.tagset_size))
        # 横轴是下一个状态，竖轴是前一个的；
        # START转入，STOP转出，概率为0，e^-10000=0，所以这么搞，进行设置
        self.transitions.data[tag_to_ix[START_TAG], :] = -10000
        self.transitions.data[:, tag_to_ix[STOP_TAG]] = -10000

        self.hidden = self.init_hidden()

    def init_hidden(self):
        return (torch.ones(2, 1, self.hidden_dim // 2),
                torch.ones(2, 1, self.hidden_dim // 2))

    def forward(self, sentence):
        # 预测时用，拿到lstm输出
        lstm_feats = self._get_lstm_features(sentence)
        # viterbi解码得到最大概率序列
        score, tag_seq = self._viterbi_decode(lstm_feats)
        return score, tag_seq

    def _viterbi_decode(self, lstm_feats):
        backpointers = []
        # 初始时START概率最s大
        init_vvars = torch.full((1, self.tagset_size), -10000.)
        init_vvars[0][self.tag_to_ix[START_TAG]] = 0

        forward_var = init_vvars
        for feat in lstm_feats:
            bptrs_t = []  # 记录最近路径的路径
            viterbivars_t = []  # 记录到每个状态最佳分数
            # 求前一时刻forward_var每个状态，到当前next_tag时刻，的最大概率，计为前一时刻状态转移成next_tag的概率
            for next_tag in range(self.tagset_size):
                next_tag_var = forward_var + self.transitions[next_tag]
                best_tag_id = argmax(next_tag_var)  # 前一时刻到next_tag的最大概率的tag
                bptrs_t.append(best_tag_id)
                viterbivars_t.append(next_tag_var[0][best_tag_id].view(1))

            forward_var = (torch.cat(viterbivars_t) + feat).view(1, -1)
            backpointers.append(bptrs_t)

        # 前一时刻到 STOP_TAG
        terminal_var = forward_var + self.transitions[self.tag_to_ix[STOP_TAG]]
        # 前一时刻到 STOP_TAG的最大分数的tag
        best_tag_id = argmax(terminal_var)
        # 最终最大的分数
        path_score = terminal_var[0][best_tag_id]

        best_path = [best_tag_id]
        # 从后往前倒推
        for bptrs_t in reversed(backpointers):
            # 前一时刻到best_tag_id的tag_id是bptrs_t[best_tag_id]
            best_tag_id = bptrs_t[best_tag_id]
            best_path.append(best_tag_id)
        # 应该第一个是START
        start = best_path.pop()
        assert start == self.tag_to_ix[START_TAG]
        best_path.reverse()
        return path_score, best_path

    # 预测序列的得分
    def _forward_alg(self, feats):
        # 前向算法，训练
        init_alphas = torch.full((1, self.tagset_size), -10000.)
        # 第一个状态，总为为START
        init_alphas[0][self.tag_to_ix[START_TAG]] = 0.

        # Wrap in a variable so that we will get automatic backprop
        forward_var = init_alphas

        # 迭代句子的每一个词的状态概率
        for feat in feats:
            alphas_t = []  # The forward tensors at this timestep
            for next_tag in range(self.tagset_size):
                # 下一节点分数（状态分数）
                emit_score = feat[next_tag].view(1, -1).expand(1, self.tagset_size)
                # 下一个的边（转移）分数
                trans_score = self.transitions[next_tag].view(1, -1)
                # 当前的分数可以由上一步的总得分+转移得分+状态得分得到
                next_tag_var = forward_var + trans_score + emit_score
                # 累计到当前步时，为next_tag状态的分数
                logsumexp = log_sum_exp(next_tag_var).view(1)
                alphas_t.append(logsumexp)
            forward_var = torch.cat(alphas_t).view(1, -1)
        terminal_var = forward_var + self.transitions[self.tag_to_ix[STOP_TAG]]
        alpha = log_sum_exp(terminal_var)
        return alpha

    def _get_lstm_features(self, sentence):
        self.hidden = self.init_hidden()
        embeds = self.word_embeds(sentence).view(len(sentence), 1, -1)
        lstm_out, self.hidden = self.lstm(embeds, self.hidden)
        lstm_out = lstm_out.view(len(sentence), self.hidden_dim)
        # 得到标签（节点权重，节点预测概率）预测
        lstm_feats = self.hidden2tag(lstm_out)
        return lstm_feats

    def _score_sentence(self, feats, tags):
        # 当前句子的分数/训练、真的数据，有字有TAG
        score = torch.zeros(1)
        # 拼接<START>
        tags = torch.cat([torch.tensor([self.tag_to_ix[START_TAG]], dtype=torch.long), tags])
        for i, feat in enumerate(feats):
            score = score + self.transitions[tags[i + 1], tags[i]] + feat[tags[i + 1]]
        # # 拼接<STOP>
        score = score + self.transitions[self.tag_to_ix[STOP_TAG], tags[-1]]
        return score

    def neg_log_likelihood(self, sentence, tags):
        # 极大似然
        # 得到LSTM输出的，字的状态概率，发射矩阵，seq_len x tags_size
        feats = self._get_lstm_features(sentence)
        # 去计算sentence所有可能的TAG的分数
        forward_score = self._forward_alg(feats)
        # 去计算当前句子的分数/训练、真的数据，有字有TAG
        gold_score = self._score_sentence(feats, tags)
        # 真实的数据的分数gold_score和总分数越接近，则拟合/给真实的概率越接近1的预测，
        # 也就是希望forward_score - gold_score越小越好（越接近越好）
        return forward_score - gold_score


START_TAG = "<START>"
STOP_TAG = "<STOP>"
EMBEDDING_DIM = 5
HIDDEN_DIM = 4

# Make up some training data
training_data = [(
    "the wall street journal reported today that apple corporation made money".split(),
    "B I I I O O O B I O O".split()
), (
    "georgia tech is a university in georgia".split(),
    "B I O O O O B".split()
)]

word_to_ix = {}
for sentence, tags in training_data:
    for word in sentence:
        if word not in word_to_ix:
            word_to_ix[word] = len(word_to_ix)

tag_to_ix = {"B": 0, "I": 1, "O": 2, START_TAG: 3, STOP_TAG: 4}

model = BiLSTM_CRF(len(word_to_ix), tag_to_ix, EMBEDDING_DIM, HIDDEN_DIM)
optimizer = optim.SGD(model.parameters(), lr=0.01, weight_decay=1e-4)

with torch.no_grad():
    precheck_sent = prepare_sequence(training_data[0][0], word_to_ix)
    precheck_tags = torch.tensor([tag_to_ix[t] for t in training_data[0][1]], dtype=torch.long)
    # forword
    print(model(precheck_sent))

for epoch in range(300):
    for sentence, tags in training_data:
        model.zero_grad()

        # 准备输入训练数据
        sentence_in = prepare_sequence(sentence, word_to_ix)
        targets = torch.tensor([tag_to_ix[t] for t in tags], dtype=torch.long)

        # 进行前向传播，计算损失。neg_log_likelihood，而不是forword
        loss = model.neg_log_likelihood(sentence_in, targets)
        # 反向传播，更新参数
        loss.backward()
        optimizer.step()

with torch.no_grad():
    precheck_sent = prepare_sequence(training_data[0][0], word_to_ix)
    # 预测，进行forword
    print(model(precheck_sent))
