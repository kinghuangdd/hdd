import torch
import torch.autograd as autograd
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

'''
rnn = nn.LSTM(10, 20, 2)
input = torch.randn(5, 3, 10) # (seq_len, batch, input_size): 
h0 = torch.randn(2, 3, 20) # (num_layers * num_directions, batch, hidden_size)
c0 = torch.randn(2, 3, 20) # (num_layers * num_directions, batch, hidden_size)
output, (hn, cn) = rnn(input, (h0, c0))

# 嗯，batch 在第二个维度：https://www.jianshu.com/p/41c15d301542
# output (seq_len, batch, num_directions * hidden_size)
# hn  (num_layers * num_directions, batch, hidden_size)
'''


class LSTMTagger(nn.Module):

    def __init__(self, embedding_dim, hidden_dim, vocab_size, tagset_size):
        super(LSTMTagger, self).__init__()
        self.hidden_dim = hidden_dim

        self.word_embeddings = nn.Embedding(vocab_size, embedding_dim)

        # The LSTM takes word embeddings as inputs, and outputs hidden states
        # with dimensionality hidden_dim.
        self.lstm = nn.LSTM(embedding_dim, hidden_dim)

        # The linear layer that maps from hidden state space to tag space
        self.hidden2tag = nn.Linear(hidden_dim, tagset_size)
        self.hidden = self.init_hidden()

    def init_hidden(self):
        # Before we've done anything, we dont have any hidden state.
        # Refer to the Pytorch documentation to see exactly why they have this dimensionality.
        # The axes semantics are (num_layers, minibatch_size, hidden_dim)
        return (autograd.Variable(torch.zeros(1, 2, self.hidden_dim)),
                autograd.Variable(torch.zeros(1, 2, self.hidden_dim)))

    def forward(self, sentence):
        batch_size, seq_len = sentence.size()
        embeds = self.word_embeddings(sentence)
        input = embeds.view(seq_len, batch_size, -1)
        # [seq_len,b,ebd_dim]
        lstm_out, self.hidden = self.lstm(input, self.hidden)
        # [b,seq_len,ebd_dim]
        lstm_out = lstm_out.transpose(0, 1)
        tag_space = self.hidden2tag(lstm_out)
        tag_scores = F.log_softmax(tag_space)
        return tag_scores


def prepare_sequence(seqs, to_ix):
    tensor = []
    for seq in seqs:
        idxs = [to_ix[w] for w in seq]
        tensor.append(idxs)
    return autograd.Variable(torch.LongTensor(tensor))


# 词，词性
training_data = [
    ("The dog ate the apple".split(), ["DET", "NN", "V", "DET", "NN"]),
    ("Everybody read that book".split(), ["NN", "V", "DET", "NN"])
]

word_to_ix = {}
for sent, tags in training_data:
    for word in sent:
        if word not in word_to_ix:
            word_to_ix[word] = len(word_to_ix)

tag_to_ix = {"DET": 0, "NN": 1, "V": 2}

EMBEDDING_DIM = 6
HIDDEN_DIM = 6

model = LSTMTagger(EMBEDDING_DIM, HIDDEN_DIM, len(word_to_ix), len(tag_to_ix))
loss_function = nn.NLLLoss()
optimizer = optim.SGD(model.parameters(), lr=0.1)

for epoch in range(300):
    for sentence, tags in training_data:
        model.zero_grad()
        model.hidden = model.init_hidden()

        sentence_in = prepare_sequence([sentence, sentence], word_to_ix)
        # [2,5]
        targets = prepare_sequence([tags, tags], tag_to_ix)
        # [10]
        targets = targets.view(-1)
        # [2,5,3]，2个样本，每个样本5个预测，3分类
        tag_scores = model(sentence_in)
        # [10,3]，需要拉成2维，预测对象，预测概率
        tag_scores = tag_scores.view(-1, tag_scores.size()[-1])
        loss = loss_function(tag_scores, targets)
        print(epoch, loss)
        loss.backward()
        optimizer.step()
