# coding:utf-8
# @Time     : 2018/10/26 下午4:16
# @Author   : 程杨
# @Discribe : 借贷类app
class Node(object):
    def __init__(self):
        self.term = None
        self.next = {}


class Trie(object):
    def __init__(self, terms=[]):
        self.root = Node()
        for term in terms:
            self.add(term)

    def add(self, term):
        node = self.root
        for char in term:
            if not char in node.next:
                node.next[char] = Node()
            node = node.next[char]
        node.term = term

    def match(self, query):
        result = []
        for i in range(len(query)):
            node = self.root
            for j in range(i, len(query)):
                node = node.next.get(query[j])
                if not node:
                    break
                if node.term:
                    result.append(node.term)
        return result

