# coding:utf-8
#2019/10/30

import datetime
import numpy as np
import time
import pandas as pd
import traceback
# from AC_20190501 import Trie,Node
import joblib
#from os.path import dirname, abspath
import jieba
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn import linear_model
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from scipy import sparse
import joblib
import json

class Extractor():
    def __init__(self,stopwords_path):
        #self.stopPath = '/search/hadoop05/suanfa/kinghuangdd/processor/停用词2751.txt'
        self.stops = set(open(stopwords_path, 'r').read().splitlines())
        #self.data = pd.read_csv(rawpath,sep='\t', encoding='utf-8', header=None, chunksize=10)
        #self.rawpath = '/search/hadoop05/suanfa/kinghuangdd/input_Data/temp'
    # 转换时间戳为时间
    def time_transform(self, time_stamp):
        return time.strftime("%Y%m%d%H%M%S", time.localtime(int(time_stamp / 1000)))

    # 计算两个时间相差的天数
    def get_time_diff(self, a, b):
        diff = (datetime.datetime(int(str(int(a))[0:4]), int(str(int(a))[4:6]), int(str(int(a))[6:8])) -
                datetime.datetime(int(str(int(b))[0:4]), int(str(int(b))[4:6]), int(str(int(b))[6:8]))).days
        return diff

    # 求两个集合的交集
    def get_repeat(self, set1, set2):
        return [e for e in set1 if e in set2]

    # 根据相差天数计算对应日期
    def get_tar_date(self, date, diff):
        date = datetime.datetime(int(str(int(date))[0:4]), int(str(int(date))[4:6]), int(str(int(date))[6:8]))
        return datetime.datetime.strftime(date - datetime.timedelta(days=diff), '%Y%m%d')

    # 转换输入数据的时间
    def time_transform_input(self, time_stamp):
        try:
            int(time_stamp)
            return int(time.strftime("%Y%m%d", time.localtime(int(time_stamp))))
        except:
            return -1

    # 去除非中文字符
    def get_cn(self,text):
        sen = ''
        text = str(text)
        for c in text:
            if u'\u4e00' <= c and c <= u'\u9fff':
                sen += c
        return sen

    # 创建停用词list
    def stopwordslist(self,filepath):
        stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
        return stopwords

    def seg_token(self,content):
        # 加去停用词  分词
        # stopwords = self.stopwordslist('/search/hadoop05/suanfa/kinghuangdd/processor/停用词2751.txt')
        # set_stopwords = set(stopwords)
        content_list = []
        try:
            word_list = jieba.cut_for_search(content)
            word_list = [self.get_cn(word) for word in word_list]
            for word in word_list:
                if word not in self.stops:
                    if word != '':
                        content_list.append(word)
            str_content = ' '.join(content_list)
            return str_content
        except:
            print('wrong seg!')
            return ''

    # 计算content app 时序特征
    def get_content_app(self, apply_time, input_his_data, input_db_data):
        time_90_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=90), '%Y%m%d'))
        time_30_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=30), '%Y%m%d'))
        time_15_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=15), '%Y%m%d'))
        try:
            if len(input_his_data) > 0:
                input_his_data = json.loads(input_his_data.replace("\'", "\"").replace('\\', '\\\\'))
                # 处理his数据  分词 去停用词 去非中文字符
                df_input_his = pd.DataFrame(input_his_data)
                df_input_his['input_date'] = df_input_his['input_time'].apply(lambda x: self.time_transform_input(x))
                df_input_his = df_input_his.sort_values('input_date', ascending=False)

                # 划分时间区间
                df_input_his_90 = df_input_his[
                    (df_input_his['input_date'] > time_90_day) & (df_input_his['input_date'] <= apply_time)].copy()
                df_input_his_30 = df_input_his[
                    (df_input_his['input_date'] > time_30_day) & (df_input_his['input_date'] <= apply_time)].copy()
                df_input_his_15 = df_input_his[
                    (df_input_his['input_date'] > time_15_day) & (df_input_his['input_date'] <= apply_time)].copy()

                # 90天数据
                df_input_his_90['content'] = df_input_his_90['content'].apply(lambda x: self.seg_token(x))
                his_temp_list_90= list(df_input_his_90['content'])##去除''空字符
                his_content_list_90 = list(filter(None,his_temp_list_90))
                his_temp2_list_90 = list(df_input_his_90['package_name'])  ##去除''空字符
                his_app_list_90 = list(filter(None, his_temp2_list_90))

                # 30天数据
                df_input_his_30['content'] = df_input_his_30['content'].apply(lambda x: self.seg_token(x))
                his_temp_list_30 = list(df_input_his_30['content'])  ##去除''空字符
                his_content_list_30 = list(filter(None, his_temp_list_30))
                his_temp2_list_30 = list(df_input_his_30['package_name'])  ##去除''空字符
                his_app_list_30 = list(filter(None, his_temp2_list_30))

                # 15天数据
                df_input_his_15['content'] = df_input_his_15['content'].apply(lambda x: self.seg_token(x))
                his_temp_list_15 = list(df_input_his_15['content'])  ##去除''空字符
                his_content_list_15 = list(filter(None, his_temp_list_15))
                his_temp2_list_15 = list(df_input_his_15['package_name'])  ##去除''空字符
                his_app_list_15 = list(filter(None, his_temp2_list_15))
            else:
                his_content_list_90 = []
                his_app_list_90 = []
                his_content_list_30 = []
                his_app_list_30 = []
                his_content_list_15 = []
                his_app_list_15 = []
        except Exception as e:
            his_content_list_90 = []
            his_app_list_90 = []
            his_content_list_30 = []
            his_app_list_30 = []
            his_content_list_15 = []
            his_app_list_15 = []

        # 处理db数据
        if len(input_db_data) > 0:
            input_db_data = json.loads(input_db_data.replace("\'", "\"").replace('\\', '\\\\'))
            df_input_db = pd.DataFrame(input_db_data)
            df_input_db = df_input_db.sort_values('date',ascending=False)
            df_input_db['content'] = df_input_db['data'].apply(lambda x: self.seg_token(' '.join([data['content'] for data in x])))
            df_input_db['app'] = df_input_db['data'].apply(lambda x: self.seg_token(' '.join([data['package_name'] for data in x])))

            # 划分时间区间
            df_input_db_90 = df_input_db[(df_input_db['date'] > str(time_90_day)) & (df_input_db['date'] <= str(apply_time))].copy()
            df_input_db_30 = df_input_db[(df_input_db['date'] > str(time_30_day)) & (df_input_db['date'] <= str(apply_time))].copy()
            df_input_db_15 = df_input_db[(df_input_db['date'] > str(time_15_day)) & (df_input_db['date'] <= str(apply_time))].copy()

            # 90天数据
            db_temp_list_90 = list(df_input_db_90['content'])##去除''空字符
            db_content_list_90 = list(filter(None,db_temp_list_90))
            db_temp2_list_90 = list(df_input_db_90['app'])  ##去除''空字符
            db_app_list_90 = list(filter(None, db_temp2_list_90))

            # 30天数据
            db_temp_list_30 = list(df_input_db_30['content'])  ##去除''空字符
            db_content_list_30 = list(filter(None, db_temp_list_30))
            db_temp2_list_30 = list(df_input_db_30['app'])  ##去除''空字符
            db_app_list_30 = list(filter(None, db_temp2_list_30))

            # 15天数据
            db_temp_list_15 = list(df_input_db_15['content'])  ##去除''空字符
            db_content_list_15 = list(filter(None, db_temp_list_15))
            db_temp2_list_15 = list(df_input_db_15['app'])  ##去除''空字符
            db_app_list_15 = list(filter(None, db_temp2_list_15))
        else:
            db_content_list_90 = []
            db_app_list_90 = []
            db_content_list_30 = []
            db_app_list_30 = []
            db_content_list_15 = []
            db_app_list_15 = []

        # 合并数据
        content_90 = ' '.join(db_content_list_90 + his_content_list_90)
        app_90 = ' '.join(db_app_list_90 + his_app_list_90)
        content_30 = ' '.join(db_content_list_30 + his_content_list_30)
        app_30 = ' '.join(db_app_list_30 + his_app_list_30)
        content_15 = ' '.join(db_content_list_15 + his_content_list_15)
        app_15 = ' '.join(db_app_list_15 + his_app_list_15)

        return content_90, content_30, content_15, app_90, app_30, app_15

    # def processor_rawdata(self, data):
    #     df = data
    #     for index, chunk in enumerate(df):
    #         print('')
    #         print('chunk index : {}'.format(index))
    #         df_input = chunk.copy()
    #         df_input.columns = ['uid', 'imei/idfa', 'apply_date', '产品名', '平台', 'input_his_data', 'input_db_data']
    #         df_input = df_input.fillna('')
    #         df_input['index'] = range(len(df_input))
    #
    #         temp = df_input.apply(lambda x: self.get_content_app(x['apply_date'], json.loads(x['input_his_data']),json.loads(x['input_db_data'])), axis=1)
    #         #第一批数据可能有格式问题，需要替换  db_data = db_data.replace("\'","\"").replace('\\','\\\\')
    #
    #         df_input['content_90'] = temp.apply(lambda x: x[0])
    #         df_input['content_30'] = temp.apply(lambda x: x[1])
    #         df_input['content_15'] = temp.apply(lambda x: x[2])
    #         df_input['app_90'] = temp.apply(lambda x: x[3])
    #         df_input['app_30'] = temp.apply(lambda x: x[4])
    #         df_input['app_15'] = temp.apply(lambda x: x[5])
    #         with open("/search/hadoop05/suanfa/kinghuangdd/input_Data/processed_"+str(12)+".pkl", 'ab') as fo:  # 将数据写入pkl文件
    #             pickle.dump(df_input, fo) # 将数据写入pkl文件
    def processor_rawdata(self, data):
        df_input = data
        df_input.columns = ['uid', 'imei/idfa', 'apply_date', '产品名', '平台', 'input_his_data', 'input_db_data']
        df_input = df_input.fillna('')
        df_input['index'] = range(len(df_input))
        #temp = df_input.apply(lambda x: self.get_content_app(x['apply_date'], eval(x['input_his_data']),eval(x['input_db_data'])), axis=1)
        #temp = df_input.apply(lambda x: self.get_content_app(x['apply_date'], json.loads(x['input_his_data']),json.loads(x['input_db_data'])), axis=1)
        temp = df_input.apply(lambda x: self.get_content_app(x['apply_date'], x['input_his_data'],x['input_db_data']), axis=1)

        # ##第一批数据可能有格式问题，需要替换  db_data = db_data.replace("\'","\"").replace('\\','\\\\')

        df_input['content_90'] = temp.apply(lambda x: x[0])
        df_input['content_30'] = temp.apply(lambda x: x[1])
        df_input['content_15'] = temp.apply(lambda x: x[2])
        df_input['app_90'] = temp.apply(lambda x: x[3])
        df_input['app_30'] = temp.apply(lambda x: x[4])
        df_input['app_15'] = temp.apply(lambda x: x[5])
        df_input = df_input.drop(['input_his_data', 'input_db_data'], axis=1)

        with open("/search/hadoop05/suanfa/kinghuangdd/input_Data/processed_"+str(15)+".pkl", 'ab') as fo:  # 将数据写入pkl文件
            pickle.dump(df_input, fo) # 将数据写入pkl文件
        print('done!')
