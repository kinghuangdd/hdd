# coding:utf-8
#2019/10/30

import datetime
import numpy as np
import time
import pandas as pd
import traceback
from AC_20190501 import Trie,Node
import joblib
#from os.path import dirname, abspath
import jieba
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn import linear_model
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from scipy import sparse
import joblib

class Extractor():
    def __init__(self, pre_trained_path):
        self.input_bin_content90 = joblib.load(f"{pre_trained_path}feature_content90.pkl")
        self.input_bin_app90 = joblib.load(f"{pre_trained_path}feature_app90.pkl")
        self.input_lgbcontent_90 = joblib.load(f"{pre_trained_path}content.pkl")
        self.input_lgbapp_90 = joblib.load(f"{pre_trained_path}app.pkl")
        self.ac_input_content90 = Trie(self.input_bin_content90.get_feature_names())
        self.ac_input_app90 = Trie(self.input_bin_app90.get_feature_names())

        self.input_bin_content30 = joblib.load(f"{pre_trained_path}feature_content30.pkl")
        self.input_bin_app30 = joblib.load(f"{pre_trained_path}feature_app30.pkl")
        self.input_lgbcontent_30 = joblib.load(f"{pre_trained_path}content_30.pkl")
        self.input_lgbapp_30 = joblib.load(f"{pre_trained_path}app_30.pkl")
        self.ac_input_content30 = Trie(self.input_bin_content30.get_feature_names())
        self.ac_input_app30 = Trie(self.input_bin_app30.get_feature_names())

    # 转换时间戳为时间
    def time_transform(self, time_stamp):
        return time.strftime("%Y%m%d%H%M%S", time.localtime(int(time_stamp / 1000)))

    # 计算两个时间相差的天数
    def get_time_diff(self, a, b):
        diff = (datetime.datetime(int(str(int(a))[0:4]), int(str(int(a))[4:6]), int(str(int(a))[6:8])) -
                datetime.datetime(int(str(int(b))[0:4]), int(str(int(b))[4:6]), int(str(int(b))[6:8]))).days
        return diff

    # 求两个集合的交集
    def get_repeat(self, set1, set2):
        return [e for e in set1 if e in set2]

    # 根据相差天数计算对应日期
    def get_tar_date(self, date, diff):
        date = datetime.datetime(int(str(int(date))[0:4]), int(str(int(date))[4:6]), int(str(int(date))[6:8]))
        return datetime.datetime.strftime(date - datetime.timedelta(days=diff), '%Y%m%d')

    # 转换输入数据的时间
    def time_transform_input(self, time_stamp):
        try:
            int(time_stamp)
            return int(time.strftime("%Y%m%d", time.localtime(int(time_stamp))))
        except:
            return -1

    # 去除非中文字符
    def get_cn(self,text):
        sen = ''
        text = str(text)
        for c in text:
            if u'\u4e00' <= c and c <= u'\u9fff':
                sen += c
        return sen

    # 创建停用词list
    def stopwordslist(self,filepath):
        stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
        return stopwords

    def seg_token(self,content):
        # 加去停用词  分词
        stopwords = self.stopwordslist('/search/hadoop05/suanfa/kinghuangdd/processor/停用词2751.txt')
        set_stopwords = set(stopwords)
        content_list = []
        try:
            word_list = jieba.cut_for_search(content)
            word_list = [self.get_cn(word) for word in word_list]
            for word in word_list:
                if word not in set_stopwords:
                    if word != '':
                        content_list.append(word)
            str_content = ' '.join(content_list)
            return str_content
        except:
            print('wrong seg!')
            return ''

    # 计算content app 时序特征
    def get_input_score(self, apply_time, input_his_data, input_db_data):
        time_90_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=90), '%Y%m%d'))
        time_30_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=30), '%Y%m%d'))
        time_15_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=15), '%Y%m%d'))
        try:
            if len(input_his_data) > 0:
                # 处理his数据  分词 去停用词 去非中文字符
                df_input_his = pd.DataFrame(input_his_data)
                df_input_his['input_date'] = df_input_his['input_time'].apply(lambda x: self.time_transform_input(x))
                df_input_his = df_input_his.sort_values('input_date', ascending=False)

                # 划分时间区间
                df_input_his_90 = df_input_his[
                    (df_input_his['input_date'] > time_90_day) & (df_input_his['input_date'] <= apply_time)].copy()
                df_input_his_30 = df_input_his[
                    (df_input_his['input_date'] > time_30_day) & (df_input_his['input_date'] <= apply_time)].copy()
                df_input_his_15 = df_input_his[
                    (df_input_his['input_date'] > time_15_day) & (df_input_his['input_date'] <= apply_time)].copy()

                # 90天数据
                df_input_his_90['content'] = df_input_his_90['content'].apply(lambda x: self.seg_token(x))
                his_temp_list_90= list(df_input_his_90['content'])##去除''空字符
                his_content_list_90 = list(filter(None,his_temp_list_90))
                his_temp2_list_90 = list(df_input_his_90['package_name'])  ##去除''空字符
                his_app_list_90 = list(filter(None, his_temp2_list_90))

                # 30天数据
                df_input_his_30['content'] = df_input_his_30['content'].apply(lambda x: self.seg_token(x))
                his_temp_list_30 = list(df_input_his_30['content'])  ##去除''空字符
                his_content_list_30 = list(filter(None, his_temp_list_30))
                his_temp2_list_30 = list(df_input_his_30['package_name'])  ##去除''空字符
                his_app_list_30 = list(filter(None, his_temp2_list_30))

                # 15天数据
                df_input_his_15['content'] = df_input_his_15['content'].apply(lambda x: self.seg_token(x))
                his_temp_list_15 = list(df_input_his_15['content'])  ##去除''空字符
                his_content_list_15 = list(filter(None, his_temp_list_15))
                his_temp2_list_15 = list(df_input_his_15['package_name'])  ##去除''空字符
                his_app_list_15 = list(filter(None, his_temp2_list_15))
            else:
                his_content_list_90 = []
                his_app_list_90 = []
                his_content_list_30 = []
                his_app_list_30 = []
                his_content_list_15 = []
                his_app_list_15 = []
        except Exception as e:
            his_content_list_90 = []
            his_app_list_90 = []
            his_content_list_30 = []
            his_app_list_30 = []
            his_content_list_15 = []
            his_app_list_15 = []

        # 处理db数据
        if len(input_db_data) > 0:
            df_input_db = pd.DataFrame(input_db_data)
            df_input_db = df_input_db.sort_values('date',ascending=False)
            df_input_db['content'] = df_input_db['data'].apply(lambda x: self.seg_token(' '.join([data['content'] for data in x])))
            df_input_db['app'] = df_input_db['data'].apply(lambda x: self.seg_token(' '.join([data['package_name'] for data in x])))

            # 划分时间区间
            df_input_db_90 = df_input_db[(df_input_db['date'] > str(time_90_day)) & (df_input_db['date'] <= str(apply_time))].copy()
            df_input_db_30 = df_input_db[(df_input_db['date'] > str(time_30_day)) & (df_input_db['date'] <= str(apply_time))].copy()
            df_input_db_15 = df_input_db[(df_input_db['date'] > str(time_15_day)) & (df_input_db['date'] <= str(apply_time))].copy()

            # 90天数据
            db_temp_list_90 = list(df_input_db_90['content'])##去除''空字符
            db_content_list_90 = list(filter(None,db_temp_list_90))
            db_temp2_list_90 = list(df_input_db_90['content'])  ##去除''空字符
            db_app_list_90 = list(filter(None, db_temp2_list_90))

            # 30天数据
            db_temp_list_30 = list(df_input_db_30['content'])  ##去除''空字符
            db_content_list_30 = list(filter(None, db_temp_list_30))
            db_temp2_list_30 = list(df_input_db_30['content'])  ##去除''空字符
            db_app_list_30 = list(filter(None, db_temp2_list_30))

            # 15天数据
            db_temp_list_15 = list(df_input_db_15['content'])  ##去除''空字符
            db_content_list_15 = list(filter(None, db_temp_list_15))
            db_temp2_list_15 = list(df_input_db_15['content'])  ##去除''空字符
            db_app_list_15 = list(filter(None, db_temp2_list_15))
        else:
            db_content_list_90 = []
            db_app_list_90 = []
            db_content_list_30 = []
            db_app_list_30 = []
            db_content_list_15 = []
            db_app_list_15 = []

        # 合并数据，优先选择db输入数据前50w字符
        # content_90 = ' '.join(db_content_list_90 + his_content_list_90)
        # content_words_90 = set(self.ac_input_content90.match(content_90))
        # app_90 = ' '.join(db_app_list_90 + his_app_list_90)
        # app_words = set(self.ac_input_app90.match(app))
        # content_values = self.input_bin_content90.transform([' '.join(content_words)]).astype(float)
        # input_content_score = round(self.input_lgbcontent_90.predict_proba(content_values)[0][1] * 1000, 2)
        # app_values = self.input_bin_app90.transform([' '.join(app_words)]).astype(float)
        # input_app_score = round(self.input_lgbapp_90.predict_proba(app_values)[0][1] * 1000, 2)

        content_30 = ' '.join(db_content_list_30 + his_content_list_30)
        content_words_30 = set(self.ac_input_content30.match(content_30))
        app_30 = ' '.join(db_app_list_30 + his_app_list_30)
        app_words_30 = set(self.ac_input_app30.match(app_30))
        content_values_30 = self.input_bin_content30.transform([' '.join(content_words_30)]).astype(float)
        input_content_score = round(self.input_lgbcontent_30.predict_proba(content_values_30)[0][1] * 1000, 2)
        app_values_30 = self.input_bin_app90.transform([' '.join(app_words_30)]).astype(float)
        input_app_score = round(self.input_lgbapp_30.predict_proba(app_values_30)[0][1] * 1000, 2)

        return input_content_score,input_app_score

    def parse(self, apply_time, input_history_data, input_database_data):
        from collections import OrderedDict
        res = OrderedDict()
        res['InputContentState'] = 'succeed'
        res['InputAppState'] = 'succeed'
        res['InputErrorV0300'] = ''
        # 计算input特征和得分
        if len(input_history_data) == 0 and len(input_database_data) == 0:
            res['InputContentState'] = 'empty'
            res['InputAppState'] = 'empty'
            res['InputContentScore'] = None
            res['InputAppScore'] = None
        else:
            try:
                res['InputContentScore'],res['InputAppScore']= self.get_input_score(apply_time, input_history_data, input_database_data)
            except Exception as e:
                err_message = traceback.format_exc(limit=1)
                res['InputErrorV0300'] = err_message
                res['InputContentScore'] =None
                res['InputAppScore'] = None
        return res
