# 提取文本中的中文
def get_cn(text):
    sen = ''
    text = str(text)
    for c in text:
        if u'\u4e00' <= c and c <= u'\u9fff':
            sen += c
    return sen


# 转换时间戳为时间
def time_transform(time_stamp):
    try:
        res = time.strftime("%Y%m%d", time.localtime(int(time_stamp)))
        return res
    except:
        return ''


# 提取input特征
def get_input_feature(apply_date, input_his_data, input_db_data, index):
    print(index, end=' ')
    from collections import OrderedDict
    user_dict = OrderedDict()
    time_90_day = int(
        datetime.datetime.strftime(datetime.datetime.strptime(str(apply_date), '%Y%m%d') - \
                                   datetime.timedelta(days=90), '%Y%m%d'))
    time_30_day = int(
        datetime.datetime.strftime(datetime.datetime.strptime(str(apply_date), '%Y%m%d') - \
                                   datetime.timedelta(days=30), '%Y%m%d'))
    time_15_day = int(
        datetime.datetime.strftime(datetime.datetime.strptime(str(apply_date), '%Y%m%d') - \
                                   datetime.timedelta(days=15), '%Y%m%d'))
    if len(input_his_data) > 0:
        # 处理his数据
        df_input_his = pd.DataFrame(input_his_data)
        df_input_his['date'] = df_input_his['input_time'].apply(lambda x: time_transform(x))
        # 90天数据
        df_input_his_90 = df_input_his[
            (df_input_his['date'] > str(time_90_day)) & (df_input_his['date'] <= str(apply_date))]
        his_input_app_list_90 = list(df_input_his_90['package_name'])
        his_content_list_90 = list(df_input_his_90['content'])
        words_his_90 = jieba.cut_for_search(' '.join(his_content_list_90))
        words_his_90 = [get_cn(word) for word in words_his_90]
        words_his_90 = [word for word in words_his_90 if word != '']
        # 30天数据
        df_input_his_30 = df_input_his[
            (df_input_his['date'] > str(time_30_day)) & (df_input_his['date'] <= str(apply_date))]
        his_input_app_list_30 = list(df_input_his_30['package_name'])
        his_content_list_30 = list(df_input_his_30['content'])
        words_his_30 = jieba.cut_for_search(' '.join(his_content_list_30))
        words_his_30 = [get_cn(word) for word in words_his_30]
        words_his_30 = [word for word in words_his_30 if word != '']
        # 15天数据
        df_input_his_15 = df_input_his[
            (df_input_his['date'] > str(time_15_day)) & (df_input_his['date'] <= str(apply_date))]
        his_input_app_list_15 = list(df_input_his_15['package_name'])
        his_content_list_15 = list(df_input_his_15['content'])
        words_his_15 = jieba.cut_for_search(' '.join(his_content_list_15))
        words_his_15 = [get_cn(word) for word in words_his_15]
        words_his_15 = [word for word in words_his_15 if word != '']
    else:
        his_input_app_list_90 = []
        his_input_app_list_30 = []
        his_input_app_list_15 = []
        words_his_90 = []
        words_his_30 = []
        words_his_15 = []

    # 处理db数据
    if len(input_db_data) > 0:
        df_input_db = pd.DataFrame(input_db_data)
        df_input_db['content_num'] = df_input_db['data'].apply(lambda x: len(x))
        df_input_db['input_app'] = df_input_db['data'].apply(lambda x: ' '.join([data['package_name'] for data in x]))
        df_input_db['input_content'] = df_input_db['data'].apply(lambda x: ' '.join([data['content'] for data in x]))
        # 90天数据
        df_input_db_90 = df_input_db[
            (df_input_db['date'] > str(time_90_day)) & (df_input_db['date'] <= str(apply_date))]
        db_input_app_list_90 = ' '.join(list(df_input_db_90[df_input_db_90['input_app'] != '']['input_app'])).split(' ')
        db_input_app_list_90 = [app for app in db_input_app_list_90 if app != '']
        db_content_list_90 = ' '.join(list(df_input_db_90['input_content'])).split(' ')
        words_db_90 = jieba.cut_for_search(' '.join(db_content_list_90))
        words_db_90 = [get_cn(word) for word in words_db_90]
        words_db_90 = [word for word in words_db_90 if word != '']
        # 30天数据
        df_input_db_30 = df_input_db[
            (df_input_db['date'] > str(time_30_day)) & (df_input_db['date'] <= str(apply_date))]
        db_input_app_list_30 = ' '.join(list(df_input_db_30[df_input_db_30['input_app'] != '']['input_app'])).split(' ')
        db_input_app_list_30 = [app for app in db_input_app_list_30 if app != '']
        db_content_list_30 = ' '.join(list(df_input_db_30['input_content'])).split(' ')
        words_db_30 = jieba.cut_for_search(' '.join(db_content_list_30))
        words_db_30 = [get_cn(word) for word in words_db_30]
        words_db_30 = [word for word in words_db_30 if word != '']
        # 15天数据
        df_input_db_15 = df_input_db[
            (df_input_db['date'] > str(time_15_day)) & (df_input_db['date'] <= str(apply_date))]
        db_input_app_list_15 = ' '.join(list(df_input_db_15[df_input_db_15['input_app'] != '']['input_app'])).split(' ')
        db_input_app_list_15 = [app for app in db_input_app_list_15 if app != '']
        db_content_list_15 = ' '.join(list(df_input_db_15['input_content'])).split(' ')
        words_db_15 = jieba.cut_for_search(' '.join(db_content_list_15))
        words_db_15 = [get_cn(word) for word in words_db_15]
        words_db_15 = [word for word in words_db_15 if word != '']
    else:
        db_input_app_list_90 = []
        db_input_app_list_30 = []
        db_input_app_list_15 = []
        words_db_90 = []
        words_db_30 = []
        words_db_15 = []

    # 合并数据
    user_dict['input_app_90'] = ' '.join(set(his_input_app_list_90 + db_input_app_list_90))
    user_dict['input_app_30'] = ' '.join(set(his_input_app_list_30 + db_input_app_list_30))
    user_dict['input_app_15'] = ' '.join(set(his_input_app_list_15 + db_input_app_list_15))
    user_dict['input_90'] = ' '.join(set(words_his_90 + words_db_90))
    user_dict['input_30'] = ' '.join(set(words_his_30 + words_db_30))
    user_dict['input_15'] = ' '.join(set(words_his_15 + words_db_15))
    return user_dict