# coding:utf-8
#2019/10/30

import datetime
import numpy as np
import time
import pandas as pd
import traceback
from AC_20190501 import Trie,Node
import joblib
import jieba
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn import linear_model
import lightgbm as lgb
from scipy import sparse
import joblib

class Extractor():
    def __init__(self, pre_trained_path):
        self.input_bin_content30 = joblib.load(f"{pre_trained_path}feature_wordsAndchar_30_0906.pkl")
        self.input_lgbcontent_30 = joblib.load(f"{pre_trained_path}wordsAndchar_30_0906.pkl")
        self.ac_input_content30 = Trie(self.input_bin_content30.get_feature_names())

    # 转换输入数据的时间
    def time_transform_input(self, time_stamp):
        try:
            int(time_stamp)
            return int(time.strftime("%Y%m%d", time.localtime(int(time_stamp))))
        except:
            return -1

    # 计算content 时序特征
    def get_input_score(self, apply_time, input_his_data, input_db_data):
        time_30_day = int(
            datetime.datetime.strftime(datetime.datetime.strptime(str(apply_time), '%Y%m%d') - \
                                       datetime.timedelta(days=30), '%Y%m%d'))
        try:
            if len(input_his_data) > 0:
                # 处理his数据  分词 去停用词 去非中文字符
                df_input_his = pd.DataFrame(input_his_data)
                df_input_his['input_date'] = df_input_his['input_time'].apply(lambda x: self.time_transform_input(x))
                df_input_his = df_input_his.sort_values('input_date', ascending=False)

                # 划分时间区间
                df_input_his_30 = df_input_his[
                    (df_input_his['input_date'] > time_30_day) & (df_input_his['input_date'] <= apply_time)].copy()

                # 30天数据
                his_temp_list_30 = list(df_input_his_30['content'])  ##去除''空字符
                his_content_list_30 = list(filter(None, his_temp_list_30))
            else:
                his_content_list_30 = []
        except Exception as e:
            his_content_list_30 = []

        # 处理db数据
        if len(input_db_data) > 0:
            df_input_db = pd.DataFrame(input_db_data)
            df_input_db = df_input_db.sort_values('date',ascending=False)
            df_input_db['content'] = df_input_db['data'].apply(lambda x: ' '.join([data['content'] for data in x]))
            # 划分时间区间
            df_input_db_30 = df_input_db[(df_input_db['date'] > str(time_30_day)) & (df_input_db['date'] <= str(apply_time))].copy()

            # 30天数据
            db_temp_list_30 = list(df_input_db_30['content'])
            db_content_list_30 = list(filter(None, db_temp_list_30))##去除''空字符
        else:
            db_content_list_30 = []

        # 合并数据
        content_30 = ' '.join(db_content_list_30 + his_content_list_30)
        content_words_30 = set(self.ac_input_content30.match(content_30))
        content_values_30 = self.input_bin_content30.transform([' '.join(content_words_30)]).astype(float)
        input_content_score = round(self.input_lgbcontent_30.predict_proba(content_values_30)[0][1] * 1000, 2)
        return input_content_score

    def parse(self, apply_time, input_history_data, input_database_data):
        from collections import OrderedDict
        res = OrderedDict()
        res['InputContentState'] = 'succeed'
        res['InputErrorV0300'] = ''
        # 计算input特征和得分
        if len(input_history_data) == 0 and len(input_database_data) == 0:
            res['InputContentState'] = 'empty'
            res['InputContentScore'] = None
        else:
            try:
                res['InputContentScore']= self.get_input_score(apply_time, input_history_data, input_database_data)
            except Exception as e:
                err_message = traceback.format_exc(limit=1)
                res['InputErrorV0300'] = err_message
                res['InputContentScore'] =None
        return res
